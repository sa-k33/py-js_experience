# This is the comment format in Python
# Python does not have multi-line comment at all
# Therefore, We have to add the hashtag in every line by ourselves
