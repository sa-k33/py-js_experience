x = 1

if x == 1:
    print("x must be 1")
else:
    if x == 2:
        print("x must be 2")
    else:
        print("x must be something else")
