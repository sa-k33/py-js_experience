for i in range(100):
    print(i)
#print 0 to 99
