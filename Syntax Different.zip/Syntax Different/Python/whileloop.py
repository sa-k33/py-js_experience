x = 99
while x >= 0:
    print(x)
    x -= 1
#print 99 to 0
