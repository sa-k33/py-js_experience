# GAP converter
GPA = eval(input("Please enter your GPA! "))
if GPA > 4:
    print("You got a A+ in this course! Well done! ")
elif GPA > 3.7:
    print("You got a A in this course! Well done! ")
elif GPA > 3.3:
    print("You got a A- in this course! Well done! ")
elif GPA > 3.0:
    print("You got a B+ in this course! Not bad! ")
elif GPA > 2.7:
    print("You got a B in this course! Not bad! ")
elif GPA > 2.3:
    print("You got a B- in this course! Not bad! ")
elif GPA > 2.0:
    print("You got a C+ in this course! Fighting! ")
elif GPA > 1.7:
    print("You got a C in this course! Fighting! ")
elif GPA > 1.0:
    print("You got a C- in this course! Fighting! ")
elif GPA == 1.0:
    print("You got a D in this course! What's wrong? ")
else:
    print(
        "You cannot even pass the course. YOU got a F, please work harder in the next semester! "
    )
