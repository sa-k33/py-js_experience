x = input("Hello, what is your preferred name?")
y = input("How old are you?")

print("Welcome, " + x + ", you are " + y + " year(s) old now!")

