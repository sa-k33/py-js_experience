//The var is the oldest keyword to declare a variable in JavaScript
var z = [] 

//The let keyword is an improved version of the var keyword
let y = 1234567 

//The const keyword has all the properties that are the same as the let keyword, except the user cannot update it
const x = "Hello World" 

