for (var i = 0; i <= 99; i++) {
    console.log(i)
}
// print 0 to 99
