/* This is the comment format in JS.
 I don't need to type the hashtag in
 every line of the comment, Yeah! */
