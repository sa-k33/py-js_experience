function welcome() {
    var x = prompt("Hello, what is your preferred name? ")
    var y = prompt("How old are you? ")
    console.log("Welcome, " + x + ", you are " + y + " year(s) old now!")
}
