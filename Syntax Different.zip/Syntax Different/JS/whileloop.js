x = 99
while (x >= 0) {
    console.log(x)
    x--
}
//print 99 to 0
