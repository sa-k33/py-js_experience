var x = 1;

if (x == 1) {
    console.log("x must be 1");
} else {
    if (x == 2) {
        console.log("x must be 2");
    } else {
        console.log("x must be something else");
    }
}
