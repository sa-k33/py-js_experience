function GpaConverter() {
    var GPA = prompt("Please enter your GPA! ")
    Number(GPA)
    if (GPA > 4) {
        GPA = "You got a A+ in this course! Well done! "
    } else if (GPA > 3.7) {
        GPA = "You got a A in this course! Well done! "
    } else if (GPA > 3.3) {
        GPA = "You got a A- in this course! Well done! "
    } else if (GPA > 3.0) {
        GPA = "You got a B+ in this course! Not bad! "
    } else if (GPA > 2.7) {
        GPA = "You got a B in this course! Not bad! "
    } else if (GPA > 2.3) {
        GPA = "You got a B- in this course! Not bad! "
    } else if (GPA > 2.0) {
        GPA = "You got a C+ in this course! Fighting! "
    } else if (GPA > 1.7) {
        GPA = "You got a C in this course! Fighting! "
    } else if (GPA > 1.0) {
        GPA = "You got a C- in this course! Fighting! "
    } else if (GPA == 1.0) {
        GPA = "You got a D in this course! What's wrong? "
    } else {
        GPA = "You cannot even pass the course. YOU got a F, please work harder in the next semester! "
    }
    console.log(GPA)
}
